/**
 * Final Project - GoodHangman
 * Written by Alexander Zaurov
 */

import java.util.HashSet;
import java.util.Set;
import java.util.Map;
import java.util.Scanner;
import java.util.LinkedList;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.HashMap;

public class GoodHangman {
    private static final int MAX_INCORRECT_GUESSES = 6;

    // Group words by length (key is length, value is word list)
    private Map<Integer, LinkedList<String>> dictionary = new HashMap<>();

    // Initially, the list of words of a given length
    // Subsequently, the words remaining based on the filter
    private LinkedList<String> candidates = new LinkedList<String>();

    // The key is the ptr (e.g., -ee), the value is the list of matching words (e.g., see, bee)
    private Map<String, LinkedList<String>> filter = new HashMap<String, LinkedList<String>>();

    private LinkedList<String> ptr;


    // The ptr
    private String word = "";
    // What the user typed
    private Set<Character> guesses = new HashSet<Character>();
    // What the user typed that was in the word
    private Set<Character> correct = new HashSet<Character>();
    private char letter;

    GoodHangman() {
        // Note that dictionary file has a lot of words, which makes it hard to win the game
        // Warning: I got this file from Internet, so it contains inappropriate words.
        File file = new File("dictionary.txt");
        FileReader reader;
        try {
            reader = new FileReader(file);
            Scanner scanner = new Scanner(reader);
            // adding words to HashMap. (key: word length, values: words list)
            while (scanner.hasNextLine()) {
                addWord(scanner.nextLine());
            }
            scanner.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
    // Construct the dictionary
    public void addWord(String word) {
        if (!dictionary.containsKey(word.length())) {
            dictionary.put(word.length(), new LinkedList<String>());
        }
        dictionary.get(word.length()).add(word);
    }

    // Reset the game
    public void reset() {
        guesses.clear();
        correct.clear();
        // Set a random word length (between 2 and 8)
        setLength(6);
    }
    // Begin the game by setting the word length
    // Unlike Hangman, we will not select correct answer since  we will chose ptr later.
    // So initially correct answered word should be "-----" (depends on the length)
    // And will decide candidates here
    public void setLength(int length) {
        //getting all the words that have a max length of 6 in the dictionary and setting to candidates
        candidates = dictionary.get(length);
        //writing those words to a string with a for loop
        for(int i = 0; i < length; i++)
        {
            word = word + "-";
        }


    }
    // Return the answer (we may have more than one)
    // Initially, we will need to print the "list of words" (candidates) of a given length
    // Subsequently, the words remaining based on the filter
    public String toString() {
        //creating a string that will store all the "list of words" (candidates) of a given length
        String ans = "";
        for(String w : candidates) {
            ans += " " + w;  //separating each "list of words" by " " followed by next candidate
        }
        return ans;
    }


    // The set of characters the user typed so far
    public Set<Character> getGuesses() {
        return guesses;
    }
    // Check if user typed letter is in word
    // read character by character from word and compare with typed letter
    // I used this method from ptr, but you may include this part inside ptr
    public boolean hasLetter(String word, char typed) {
        for(int i = 0; i < word.length(); i++)
            if (word.charAt(i) == typed)
                return true;
        return false;

    }

    // Given a word, construct a ptr based on what the user typed
    // If the typed character isn't in the word, return null (we don't need to create ptr for this word)
    // I called this from createFilter. Of course, you may include this part inside createFilter
    // refer to the method visible(). It is similar
    // guesses.contains(letter) || letter == typed ? letter : '-'
    public String pattern(String word, char typed) {
        //if the user makes a wrong guess, return nothing
        if(!hasLetter(word, typed)) {
            return null;
        }
        //passing word to character array
        char [] f = this.word.toCharArray();
        for(int i = 0; i < word.length(); i++) {
            if(word.charAt(i) == typed) {
                //if the user makes a right guess, each letter will be printed in the word
                f[i] = typed;
            }
        }
        return String.valueOf(f);
    }
    // Group words by common ptr
    // For example:
    // -ee => fee, see, bee, ...
    // -e- => bed, beg, bet, few, hex, ...
    public void createFilter(char typed) {
        //using the filter hashmap
        filter = new HashMap<>();
        //using the pattern hashmap
        ptr = new LinkedList<>();

        //narrowing down to the possible answers

        for(int i = 0; i < candidates.size(); i++) {
            if(pattern(candidates.get(i), typed) != null) {
                if (!filter.containsKey(pattern(candidates.get(i), typed))) {
                    filter.put(pattern(candidates.get(i), typed), new LinkedList<>());
                }
                filter.get(pattern(candidates.get(i), typed)).add(candidates.get(i));
                if(!ptr.contains(pattern(candidates.get(i), typed))) {
                    ptr.add(pattern(candidates.get(i), typed));
                }
            }
        }

    }
    // Select the ptr with the most words in it (largest linkedList size)
    // Print out filter and candidates here
    public void choosePattern(char letter) {
        //comparing the size of the linked list and then chooses the max size
        int top = 0;
        for(String v : ptr) {
            if(top <= filter.get(v).size()) {
                top = filter.get(v).size();
                candidates = filter.get(v);
                this.word = v;
            }
        }
        for(int i = 0; i < ptr.size(); i++) {
            System.out.println(ptr.get(i) + " " + filter.get(ptr.get(i)).size());
        }
        System.out.println(toString());
    }

    // User makes a guess. If the character is new, add it to the set.
    // Otherwise return false so the user may guess again
    public boolean makeGuess(char letter) {
        // Only allow lower-case a-z
        if (letter < 'a' || letter > 'z') {
            return false;
        }
        // If we already guessed, don't bother
        if (guesses.contains(letter)) {
            return false;
        }
        createFilter(letter);
        choosePattern(letter);

        guesses.add(letter);

        if (word.contains("" + letter)) {
            correct.add(letter);
        }
        return true;
    }
    // What can the player see?
    public String visible() {
        // StringBuilder concatenates all guessed letter and "-"
        StringBuilder b = new StringBuilder();
        // Compare each character from the answer with guessed letter
        for (char letter : word.toCharArray()) {
            b.append(guesses.contains(letter) ? letter : '-');
        }
        return b.toString();
    }
    // Did the player win?
    public boolean won() {
        return !hasLetter(word, '-');
    }
    // How many guesses remain?
    public int guessesRemaining() {
        return MAX_INCORRECT_GUESSES - (guesses.size() - correct.size());
    }
    // Is the game over?
    public boolean isOver() {
        return (guessesRemaining() <= 0) || won();
    }
}
